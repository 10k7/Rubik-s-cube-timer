Ohjelma "CubeTimer.py" mittaa aikaa joka kuuluu k�ytt�j�lt� rubiikin kuution selvitykseen ja antaa sekoituksen eri
kokoisille kuutioille.

Satunnaisen sekoituksen eri kuutioille saa painamalla painamalla niiden kuvaketta. Sekoituksen pituus 25 liikett� pitk�.
Lis�tietoja kuutioiden liikkeiden notaatiosta l�ytyy sivuilta: https://ruwix.com/the-rubiks-cube/algorithm/ ja
https://ruwix.com/twisty-puzzles/4x4x4-rubiks-cube-rubiks-revenge/. 3x3 ja 2x2 kuutioiden notaatio on p��osin sama, mutta
4x4 kuutiolla on enemm�n liikkeit�.

Ajastin k�ynnistyy painamalla vihre�� "start" nappia ja pys�htyy painamalla "stop" nappia, joka ilmestyi "start" napin
tilalle. Ajastimen voi my�s k�ynnist�� ja pys�htyy painamalla v�linly�nti nappia. Ajankulu n�kyy �Start/Stop� napin alla.
Selvitys aika otetaan talteen, kun yksi "start" ja "stop" vaihe on k�yty l�pi. Selvitys aikoja voi halutessaan poistaa
painamalla tallennetun ajan viereen ilmestyv�� ruksia. Kaikki ajat voidaan poistaa painamalla nappia, jossa lukee
�Clear all the times�. Kaikille selvitys ajoille my�s lasketaan keskiarvo, joka p�ivittyy automaattisesti ajastinta k�ytett�ess�.